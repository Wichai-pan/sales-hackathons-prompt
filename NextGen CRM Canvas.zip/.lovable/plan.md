
# HMD Secure CRM — 高保真 UI 设计稿

目标：在 Lovable 里产出一整套**纯前端高保真界面**（深色为主、支持浅色切换），调性是 Attio 那种冷静高端的深紫蓝 + Sora/Manrope 字体。Lovable 不接你的后端，是给你一份"可以拍照对照、把 className 和 token 抄回 Next.js 项目"的设计参考稿，符合你 `UI-RESTYLE-GUIDE.md` 里"只抄壳、不动 form/action/name"的原则。

---

## 设计系统（最关键，先定）

**Tokens（写在 `src/styles.css` 的 `@theme inline` + `:root` / `.dark`）**
- 背景层：`--background #0b0d1a` / 卡片 `#10122a` / 抬升层 `#171a3a` / 边框 `oklch(1 0 0 / 8%)`
- 文本：主 `#E7E9F5`、次 `#9CA3C7`、弱 `#6B7099`
- 主色：`--primary #6366F1` + glow `#A5B4FC`；渐变 `linear-gradient(135deg,#6366F1,#8B5CF6)`
- 状态：success `#22C55E`、warning `#F59E0B`、danger `#EF4444`、info `#38BDF8`
- 圆角：`--radius 14px`（卡片 16/20，按钮 10）
- 阴影：`shadow-elegant 0 10px 40px -10px rgba(99,102,241,.35)`
- 字体：Sora（标题）+ Manrope（正文），数字用 `font-feature-settings:"tnum"`

**共享原子**（每页都复用，所以先做好）
- `Card`（亚光玻璃 + 1px 内描边 + 顶部 1px highlight）
- `Button`（primary/ghost/outline/AI-gradient）
- `Badge`（status / stage / risk，柔和底 + 同色 1px 描边）
- `Table`（紧凑行高 36px、hover 高亮、sticky header、行内 inline-edit 视觉）
- `KpiTile`、`SparkLine`、`StageChip`、`AvatarStack`、`AIChip`（紫色脉冲点）

---

## 页面清单（每个都是独立 route，独立 head meta）

1. **`/login` Role Switch** —— 4 张人物卡（Sofia / Timo / Mira / Fiona），玻璃质感 + 角色徽章 + 一句话职责，背景一层 Aurora/Grid pattern。
2. **App Shell**（`__root` 下）—— 左侧细边栏（图标+折叠）+ 顶部全局搜索（⌘K 风格）+ 通知铃 + 角色 chip + 右下浮动 **AI Assistant** 气泡（点开抽屉式 chat，带 suggested prompts、引用卡片、流式光标）。**学 Attio 的克制 + Intercom 的 messenger 抽屉**。
3. **Sales Rep Dashboard**（Hero 页）—— 顶部 4 个 KPI tile（带 sparkline）；左大块 **AI-Assisted Intake**：贴邮件 → AI 解析成结构化卡片 + 可编辑字段 + "Create Deal" CTA；右侧 **Today's Next Best Actions** 时间线（学 Monday 的色块 + folk 的人物头像）；底部 mini pipeline 横向滚动。
4. **Pipeline / Deals**（学 **folk**）—— Kanban 看板：列=阶段、卡片=deal（公司 logo、金额、负责人、风险点、AI summary 行），可切 Table 视图；顶部 filter chips + saved views tab。
5. **Contacts / Accounts**（学 **Attio**）—— 左侧 faceted filter，主区是数据密集表格（inline edit、resizable column、relation chip），右侧 detail drawer 滑出。
6. **Account 360**（学 Attio + Clari）—— 顶部公司 header（logo / industry / health score 环形 / owner）；Tab：Overview · Deals · Activity · Devices · AI Insights；右栏常驻 **AI Insights**（Next Best Action、Risk、Recent Signal，每条带"为什么"引用源）。
7. **Case Management**（学 **Intercom**）—— 三栏：左 case 列表（搜索 + 状态过滤）、中 conversation thread（客户/TAM/AI 三色气泡 + 内部备注黄条）、右 customer context 面板（设备清单、SLA 倒计时、关联 deal）。
8. **Forecast**（学 **Clari**）—— 顶部 quarter switcher + Commit / Best Case / Pipeline 三个大数字带 delta；中部 waterfall 图（已赢→commit→best→pipe）；下方 deals 表，每行有 AI 风险标签和 forecast category 下拉；右栏 "AI Forecast Commentary" 卡。
9. **Offer / Quote Builder**（学 **Qwilr + DealHub**）—— 左侧实时预览（封面 hero + 公司品牌色 + 产品块 + 价格表 + 电子签名区，像 landing page），右侧编辑器（拖拽 block、折扣审批链可视化、approval 进度条）；顶部 "Send as web page" CTA。
10. **Sales Manager Dashboard** —— Team leaderboard + pipeline coverage heatmap + approval queue（待审折扣，AI 给出建议 approve/reject 理由）。
11. **Finance Dashboard** —— Revenue waterfall、approved discounts 表、AR aging、合同到期提醒；冷静配色（少装饰、表格优先）。
12. **Automations**（学 **Monday**）—— "When X → Then Y" 卡片式 recipe 列表 + 彩色 trigger/action chips + 启用开关；新建时是积木拼接器。
13. **AI Assistant 全屏视图** —— `/assistant` 路由，左侧 conversation 历史、中部对话（支持图表/表格/deal 卡片回复）、右侧 "Sources & Actions"。
14. **Settings / Notifications**（次要）—— profile、role、integrations grid、notification 偏好。

---

## 技术实现

```text
src/
  styles.css              ← @theme inline + 深紫蓝 tokens + Sora/Manrope
  routes/
    __root.tsx            ← Sora/Manrope <link>、AppShell（侧栏+顶栏+AI 气泡）
    index.tsx             ← 重定向到 /login（演示用）
    login.tsx
    rep.tsx               ← Sales Rep dashboard
    pipeline.tsx
    contacts.tsx
    accounts.$id.tsx      ← Account 360
    cases.tsx
    forecast.tsx
    offers.$id.tsx        ← Quote builder
    manager.tsx
    finance.tsx
    automations.tsx
    assistant.tsx
  components/
    app-shell/  (Sidebar, Topbar, AiBubble, AiDrawer, CommandK)
    primitives/ (KpiTile, SparkLine, StageChip, AvatarStack, AIChip, GlassCard)
    pipeline/   (KanbanColumn, DealCard, ViewSwitcher)
    account/    (HealthRing, InsightCard, ActivityTimeline)
    cases/      (CaseList, MessageThread, ContextPanel)
    forecast/   (WaterfallChart, ForecastTable, CommentaryCard)
    offer/      (OfferPreview, BlockEditor, ApprovalChain)
    automations/(RecipeCard, TriggerChip)
```

- 字体：`<link>` Google Fonts（Sora 400/600/700 + Manrope 400/500/700），在 `__root` head 里加，**不**用 CSS `@import`。
- 图表：`recharts`（waterfall、sparkline、heatmap）。
- 动画：`motion/react`（AI 气泡呼吸、卡片 hover lift、drawer 滑入、流式打字光标）。
- 图标：`lucide-react`（已装）。
- 全部数据用 brief 附录里的 seed mock（Sofia/Timo/Mira/Fiona、几家 enterprise 客户、几个 deal），**不接后端**——你后续按 UI-RESTYLE-GUIDE 抄 className 和 tokens 到你的 Next.js 项目即可。
- 浅色主题保留但默认 dark（`<html class="dark">`），右上角加切换。

---

## 不做的事

- 不接你的 Prisma / server actions / Featherless / 后端 API。
- 不在 form 上写真实 action（占位 `onSubmit={e=>e.preventDefault()}`，方便你回去替换）。
- 不做 i18n、不做权限校验、不做真实认证。
- 不动你已有项目的文件——这是一个**全新的 Lovable 项目**，作为设计参考稿。

确认后我会一次性把设计系统 + 14 个页面全部建出来。
