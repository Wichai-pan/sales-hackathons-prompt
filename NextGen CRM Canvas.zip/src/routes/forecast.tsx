import { createFileRoute } from "@tanstack/react-router";
import { ChevronDown, Sparkles, AlertTriangle, TrendingUp } from "lucide-react";
import { forecast, deals, accounts, fmt } from "../lib/seed";
import { AIChip, Badge, GlassCard, SectionHeader } from "../components/primitives";

export const Route = createFileRoute("/forecast")({
  head: () => ({
    meta: [
      { title: "Forecast — HMD Secure CRM" },
      { name: "description", content: "Clari-style revenue forecast with AI commentary." },
    ],
  }),
  component: Forecast,
});

function Forecast() {
  const max = Math.max(...forecast.waterfall.map(w => w.value)) * 1.1;
  const colors: Record<string, string> = {
    won: "from-emerald-500 to-emerald-400",
    commit: "from-primary to-primary-glow",
    best: "from-fuchsia-500 to-pink-400",
    pipe: "from-sky-500 to-cyan-400",
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader
        title="Forecast"
        subtitle="EMEA · live · last refreshed 4 minutes ago"
        action={
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm">{forecast.quarter} <ChevronDown className="h-3.5 w-3.5" /></button>
            <button className="inline-flex items-center gap-1.5 rounded-lg ai-gradient px-3 py-1.5 text-xs font-medium text-white"><Sparkles className="h-3.5 w-3.5" /> Submit forecast</button>
          </div>
        }
      />

      <div className="grid gap-4 lg:grid-cols-4">
        {[
          { label: "Closed", value: forecast.closed, tone: "success", delta: "+12%" },
          { label: "Commit", value: forecast.commit, tone: "primary", delta: "+8%" },
          { label: "Best case", value: forecast.bestCase, tone: "info", delta: "+15%" },
          { label: "Pipeline", value: forecast.pipeline, tone: "default", delta: "+4%" },
        ].map((k) => (
          <GlassCard key={k.label}>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{k.label}</div>
            <div className="mt-2 font-display text-3xl font-semibold tnum">{fmt(k.value)}</div>
            <div className="mt-1 text-xs text-success">{k.delta} vs last week</div>
          </GlassCard>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.7fr_1fr]">
        <GlassCard className="p-0">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div className="font-medium text-sm">Coverage waterfall — Q3</div>
            <div className="text-xs text-muted-foreground">Target {fmt(forecast.target)} · attainment 84%</div>
          </div>
          <div className="p-6">
            <div className="flex items-end justify-around gap-4 h-72">
              {forecast.waterfall.map((w) => (
                <div key={w.name} className="flex flex-1 flex-col items-center gap-2">
                  <div className="font-display text-sm font-semibold tnum">{fmt(w.value)}</div>
                  <div
                    className={`w-full rounded-t-xl bg-gradient-to-b ${colors[w.type]} shadow-elegant relative overflow-hidden`}
                    style={{ height: `${(w.value / max) * 100}%`, minHeight: 20 }}
                  >
                    <div className="absolute inset-x-0 top-0 h-px bg-white/30" />
                  </div>
                  <div className="text-xs text-muted-foreground">{w.name}</div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex items-center justify-center gap-2">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary max-w-xl">
                <div className="h-full rounded-full ai-gradient" style={{ width: `${(forecast.commit / forecast.target) * 100}%` }} />
              </div>
              <span className="text-xs text-muted-foreground tnum">{Math.round((forecast.commit / forecast.target) * 100)}% to target</span>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-0">
          <div className="flex items-center gap-2 border-b border-border px-5 py-3">
            <div className="grid h-7 w-7 place-items-center rounded-lg ai-gradient"><Sparkles className="h-3.5 w-3.5 text-white" /></div>
            <div className="font-display text-sm font-semibold ai-gradient-text">AI Forecast Commentary</div>
          </div>
          <div className="space-y-3 p-5 text-sm">
            <p>Commit is <strong className="text-success">+8%</strong> WoW driven by Telia closing early and Siemens advancing two stages.</p>
            <div className="rounded-xl border border-warning/40 bg-warning/10 p-3 text-warning">
              <div className="flex items-center gap-1.5 text-xs font-medium"><AlertTriangle className="h-3 w-3" /> Slip risk</div>
              <div className="mt-1 text-foreground text-sm">Airbus Sovereign Comms (€2.1M) is showing champion-change risk. Slip probability ~38%.</div>
            </div>
            <div className="rounded-xl border border-info/40 bg-info/10 p-3 text-info">
              <div className="flex items-center gap-1.5 text-xs font-medium"><TrendingUp className="h-3 w-3" /> Upside</div>
              <div className="mt-1 text-foreground text-sm">If Siemens expansion closes this quarter (60% odds), best-case rises to €7.4M, beating target.</div>
            </div>
            <button className="text-xs ai-gradient-text">View full analysis →</button>
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-0">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <div className="font-medium text-sm">Forecast deals</div>
          <AIChip>AI categorized 7 of 7</AIChip>
        </div>
        <table className="w-full text-sm">
          <thead className="text-xs uppercase tracking-wider text-muted-foreground">
            <tr className="border-b border-border">
              {["Deal", "Account", "Amount", "Close", "Category", "Rep judgment", "AI judgment", "Risk"].map(h => (
                <th key={h} className="px-4 py-2.5 text-left font-medium first:pl-5 last:pr-5">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {deals.map((d) => {
              const acc = accounts.find(a => a.id === d.account)!;
              const cat = d.confidence > 80 ? "Commit" : d.confidence > 55 ? "Best case" : "Pipeline";
              return (
                <tr key={d.id} className="border-b border-border/60 last:border-0 hover:bg-secondary/30">
                  <td className="px-5 py-3 font-medium">{d.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{acc.name}</td>
                  <td className="px-4 py-3 font-medium tnum">{fmt(d.amount)}</td>
                  <td className="px-4 py-3 text-muted-foreground">{d.closeDate}</td>
                  <td className="px-4 py-3">
                    <select defaultValue={cat} className="rounded-md border border-border bg-card px-2 py-1 text-xs">
                      <option>Commit</option><option>Best case</option><option>Pipeline</option><option>Omitted</option>
                    </select>
                  </td>
                  <td className="px-4 py-3"><Badge>{cat}</Badge></td>
                  <td className="px-4 py-3"><AIChip>{cat}</AIChip></td>
                  <td className="px-4 py-3 pr-5">
                    {d.risk === "high" ? <Badge tone="danger">High</Badge> : d.risk === "medium" ? <Badge tone="warning">Med</Badge> : <Badge tone="success">Low</Badge>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </GlassCard>
    </div>
  );
}
