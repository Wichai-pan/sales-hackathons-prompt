import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { ArrowLeft, Sparkles, AlertTriangle, TrendingUp, MessageCircle, Phone, Mail, Calendar, Smartphone } from "lucide-react";
import { accounts, deals, fmt } from "../lib/seed";
import { AIChip, Avatar, Badge, GlassCard, HealthRing } from "../components/primitives";

export const Route = createFileRoute("/accounts/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.id} — Account 360 · HMD Secure CRM` },
      { name: "description", content: "Account 360: deals, activity, devices and AI insights in one view." },
    ],
  }),
  component: Account360,
});

function Account360() {
  const { id } = useParams({ from: "/accounts/$id" });
  const a = accounts.find((x) => x.id === id) ?? accounts[2];
  const accountDeals = deals.filter((d) => d.account === a.id);

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <Link to="/contacts" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-3 w-3" /> All accounts
      </Link>

      {/* Header */}
      <GlassCard className="flex flex-wrap items-center gap-6 p-6">
        <Avatar initials={a.logo} hue={(a.id.length * 37) % 360} size={72} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-3">
            <h1 className="font-display text-3xl font-semibold">{a.name}</h1>
            <Badge tone="primary">{a.industry}</Badge>
            <Badge>{a.region}</Badge>
          </div>
          <div className="mt-1 text-sm text-muted-foreground">{a.devices.toLocaleString()} devices · Owner: Sofia Lindqvist · Since 2022</div>
        </div>
        <div className="grid grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">ARR</div>
            <div className="font-display text-2xl font-semibold tnum">{fmt(a.arr)}</div>
          </div>
          <div className="text-center">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Open pipeline</div>
            <div className="font-display text-2xl font-semibold tnum">{fmt(accountDeals.reduce((s, d) => d.stage !== "Closed Won" ? s + d.amount : s, 0))}</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Health</div>
            <HealthRing value={a.health} size={56} />
          </div>
        </div>
      </GlassCard>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          {/* Tabs */}
          <div className="flex gap-1 rounded-xl border border-border bg-card p-1">
            {["Overview", "Deals", "Activity", "Devices", "Contacts", "Cases"].map((t, i) => (
              <button key={t} className={`flex-1 rounded-lg px-3 py-1.5 text-sm ${i === 0 ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}>{t}</button>
            ))}
          </div>

          {/* Deals */}
          <GlassCard className="p-0">
            <div className="border-b border-border px-5 py-3 font-medium text-sm">Open deals</div>
            <div className="divide-y divide-border">
              {accountDeals.map((d) => (
                <div key={d.id} className="flex items-center justify-between px-5 py-3">
                  <div>
                    <div className="font-medium">{d.name}</div>
                    <div className="text-xs text-muted-foreground">{d.stage} · closes {d.closeDate}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-display tnum">{fmt(d.amount)}</span>
                    <Badge tone={d.stage === "Closed Won" ? "success" : "primary"}>{d.confidence}%</Badge>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* Activity timeline */}
          <GlassCard className="p-0">
            <div className="border-b border-border px-5 py-3 font-medium text-sm">Recent activity</div>
            <div className="relative px-5 py-4">
              <div className="absolute bottom-4 left-7 top-4 w-px bg-border" />
              {[
                { icon: Mail, who: "Sofia Lindqvist", text: "Sent pricing addendum for cross-border ops", when: "2h ago", tone: "default" },
                { icon: Sparkles, who: "AI", text: "Detected new champion signal — Maria Brandt mentioned HMD twice in LinkedIn this week", when: "yesterday", tone: "primary" },
                { icon: Phone, who: "Sofia Lindqvist", text: "Discovery call with CISO — 32 min · summary attached", when: "2d ago", tone: "default" },
                { icon: Calendar, who: "System", text: "Stage moved to Negotiation", when: "5d ago", tone: "default" },
                { icon: MessageCircle, who: "Timo Virtanen", text: "Posted security review notes", when: "1w ago", tone: "default" },
              ].map((e, i) => {
                const Icon = e.icon;
                return (
                  <div key={i} className="relative flex gap-4 py-2.5">
                    <div className={`relative z-10 grid h-5 w-5 shrink-0 place-items-center rounded-full ${e.tone === "primary" ? "ai-gradient" : "bg-secondary border border-border"}`}>
                      <Icon className={`h-2.5 w-2.5 ${e.tone === "primary" ? "text-white" : "text-muted-foreground"}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm"><span className="font-medium">{e.who}</span> <span className="text-muted-foreground">{e.text}</span></div>
                      <div className="text-xs text-muted-foreground">{e.when}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </GlassCard>

          {/* Devices summary */}
          <GlassCard className="p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="font-medium text-sm">Devices under management</div>
              <Badge tone="info">{a.devices.toLocaleString()} active</Badge>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {[
                { name: "HMD Pro 512", count: Math.round(a.devices * 0.6), ver: "iOS 19.2" },
                { name: "HMD Pro 256", count: Math.round(a.devices * 0.3), ver: "iOS 19.2" },
                { name: "HMD Lite", count: Math.round(a.devices * 0.08), ver: "iOS 18.7" },
                { name: "Pilot units", count: Math.round(a.devices * 0.02), ver: "iOS 20 beta" },
              ].map((d) => (
                <div key={d.name} className="rounded-lg border border-border bg-background/40 p-3">
                  <Smartphone className="mb-2 h-4 w-4 text-primary-glow" />
                  <div className="text-xs text-muted-foreground">{d.name}</div>
                  <div className="font-display text-lg font-semibold tnum">{d.count.toLocaleString()}</div>
                  <div className="text-[10px] text-muted-foreground">{d.ver}</div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* AI Insights rail */}
        <aside className="space-y-4">
          <GlassCard className="p-0">
            <div className="flex items-center gap-2 border-b border-border px-5 py-3">
              <div className="grid h-7 w-7 place-items-center rounded-lg ai-gradient"><Sparkles className="h-3.5 w-3.5 text-white" /></div>
              <div className="font-display text-sm font-semibold ai-gradient-text">AI Insights</div>
            </div>
            <div className="space-y-3 p-4">
              {[
                { icon: TrendingUp, title: "Next Best Action", body: "Schedule executive briefing — 3 expansion signals in 30d, no exec touchpoint in 90d.", tone: "primary" },
                { icon: AlertTriangle, title: "Risk", body: "Pricing pushback detected on the cross-border deal. Suggest tiered packaging.", tone: "warning" },
                { icon: Sparkles, title: "Signal", body: "Procurement contact joined a competitor webinar last Tuesday.", tone: "info" },
              ].map((i, k) => {
                const Icon = i.icon;
                return (
                  <div key={k} className="rounded-xl border border-border bg-background/40 p-3">
                    <div className="flex items-center gap-2 text-xs">
                      <Icon className={`h-3.5 w-3.5 ${i.tone === "warning" ? "text-warning" : i.tone === "info" ? "text-info" : "text-primary-glow"}`} />
                      <span className="font-medium">{i.title}</span>
                    </div>
                    <div className="mt-2 text-sm leading-snug">{i.body}</div>
                    <div className="mt-2 flex items-center justify-between">
                      <button className="text-[11px] ai-gradient-text">Why?</button>
                      <button className="rounded-md border border-border px-2 py-0.5 text-[11px] hover:bg-secondary">Act on it</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </GlassCard>

          <GlassCard className="p-4">
            <div className="mb-3 flex items-center justify-between">
              <div className="text-sm font-medium">Key contacts</div>
              <AIChip>3 champions</AIChip>
            </div>
            <div className="space-y-3">
              {[
                { name: "Maria Brandt", title: "VP Mobile Engineering", role: "Champion", hue: 280 },
                { name: "Klaus Reiner", title: "CISO", role: "Decision maker", hue: 200 },
                { name: "Ines Voss", title: "Procurement Lead", role: "Influencer", hue: 320 },
              ].map((c) => (
                <div key={c.name} className="flex items-center gap-3">
                  <Avatar initials={c.name.split(" ").map(x => x[0]).join("")} hue={c.hue} size={32} />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium leading-tight">{c.name}</div>
                    <div className="text-xs text-muted-foreground">{c.title}</div>
                  </div>
                  <Badge tone={c.role === "Champion" ? "success" : "default"}>{c.role}</Badge>
                </div>
              ))}
            </div>
          </GlassCard>
        </aside>
      </div>
    </div>
  );
}
