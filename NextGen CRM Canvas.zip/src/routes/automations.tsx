import { createFileRoute } from "@tanstack/react-router";
import { Plus, Zap, Sparkles } from "lucide-react";
import { automations } from "../lib/seed";
import { Badge, GlassCard, SectionHeader } from "../components/primitives";

export const Route = createFileRoute("/automations")({
  head: () => ({
    meta: [
      { title: "Automations — HMD Secure CRM" },
      { name: "description", content: "Monday-style if-this-then-that recipes powering your CRM." },
    ],
  }),
  component: Automations,
});

const palette = ["from-violet-500 to-fuchsia-500", "from-sky-500 to-cyan-500", "from-emerald-500 to-teal-500", "from-amber-500 to-orange-500", "from-pink-500 to-rose-500"];

function Automations() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader
        title="Automations"
        subtitle="5 recipes · 224 runs this month · saved ~38 hours of manual work"
        action={<button className="inline-flex items-center gap-1.5 rounded-lg ai-gradient px-3 py-1.5 text-xs font-medium text-white"><Plus className="h-3.5 w-3.5" /> New recipe</button>}
      />

      <GlassCard className="border-primary/30 bg-accent/20 p-5">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-lg ai-gradient"><Sparkles className="h-5 w-5 text-white" /></div>
          <div className="flex-1">
            <div className="font-medium">Tell me what to automate</div>
            <div className="text-xs text-muted-foreground">"When a deal stalls 2 weeks, ping me and the AE." — AI builds the recipe for you.</div>
          </div>
          <input placeholder="Describe an automation…" className="hidden h-10 flex-1 rounded-lg border border-border bg-background/60 px-3 text-sm md:block" />
          <button className="rounded-lg ai-gradient px-4 py-2 text-sm font-medium text-white">Generate</button>
        </div>
      </GlassCard>

      <div className="grid gap-3">
        {automations.map((a, i) => (
          <GlassCard key={a.id} className="p-0">
            <div className="flex items-center gap-4 px-5 py-4">
              <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br ${palette[i % palette.length]} shadow-elegant`}>
                <Zap className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-medium">{a.name}</div>
                <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs">
                  <span className="rounded-md border border-border bg-secondary/50 px-2 py-0.5 text-[11px]"><span className="text-muted-foreground">When </span><span className="font-medium">{a.trigger}</span></span>
                  <span className="text-muted-foreground">→</span>
                  <span className="rounded-md border border-primary/30 bg-accent/40 px-2 py-0.5 text-[11px] ai-gradient-text"><span className="opacity-70">Then </span><span className="font-medium">{a.action}</span></span>
                </div>
              </div>
              <div className="text-right text-xs">
                <div className="tnum font-medium">{a.runs}</div>
                <div className="text-muted-foreground">runs</div>
              </div>
              <Badge tone={a.on ? "success" : "default"}>{a.on ? "On" : "Off"}</Badge>
              <button className={`relative h-6 w-11 rounded-full transition-colors ${a.on ? "ai-gradient" : "bg-secondary"}`}>
                <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${a.on ? "left-[22px]" : "left-0.5"}`} />
              </button>
            </div>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="p-5">
        <div className="mb-3 font-medium text-sm">Templates</div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            "Slack me when a P1 case opens",
            "Email weekly forecast to my manager",
            "Auto-assign new leads round-robin",
            "Block discounts over 20% automatically",
          ].map((t, i) => (
            <button key={t} className="rounded-xl border border-border bg-background/40 p-4 text-left hover:border-primary/40">
              <div className={`mb-3 inline-grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br ${palette[i]} text-white`}><Zap className="h-4 w-4" /></div>
              <div className="text-sm font-medium leading-tight">{t}</div>
              <div className="mt-2 text-[11px] text-muted-foreground">Use template →</div>
            </button>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}
