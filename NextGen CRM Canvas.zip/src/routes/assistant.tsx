import { createFileRoute } from "@tanstack/react-router";
import { Sparkles, Send, Plus, MessageSquare, BarChart3, Table2 } from "lucide-react";
import { Avatar, GlassCard, AIChip } from "../components/primitives";

export const Route = createFileRoute("/assistant")({
  head: () => ({
    meta: [
      { title: "AI Assistant — HMD Secure CRM" },
      { name: "description", content: "Full-screen conversational copilot grounded in your live CRM data." },
    ],
  }),
  component: Assistant,
});

function Assistant() {
  return (
    <div className="grid h-[calc(100vh-56px)] grid-cols-[260px_1fr_320px] gap-0">
      {/* History */}
      <aside className="flex flex-col border-r border-border bg-sidebar/40 p-3">
        <button className="mb-3 inline-flex items-center justify-center gap-1.5 rounded-lg ai-gradient px-3 py-2 text-sm font-medium text-white"><Plus className="h-3.5 w-3.5" /> New chat</button>
        <div className="space-y-1 text-sm overflow-y-auto">
          {[
            "Q3 risk analysis",
            "Draft renewal email for DB",
            "Compare Nordea vs Telia ARR",
            "Top accounts losing engagement",
            "Forecast variance vs last week",
          ].map((t, i) => (
            <button key={t} className={`flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs ${i === 0 ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-secondary"}`}>
              <MessageSquare className="h-3 w-3" />
              <span className="truncate">{t}</span>
            </button>
          ))}
        </div>
      </aside>

      {/* Chat */}
      <div className="flex min-w-0 flex-col">
        <div className="flex items-center gap-2 border-b border-border px-6 py-3">
          <div className="grid h-7 w-7 place-items-center rounded-lg ai-gradient"><Sparkles className="h-3.5 w-3.5 text-white" /></div>
          <div className="font-display text-sm font-semibold ai-gradient-text">HMD Copilot</div>
          <AIChip>Grounded in live CRM</AIChip>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto p-6">
          {/* User */}
          <div className="flex justify-end gap-3">
            <div className="max-w-xl rounded-2xl rounded-tr-sm bg-accent/40 p-3 text-sm">Which deals in Q3 are at risk and why?</div>
            <Avatar initials="SL" hue={280} size={28} />
          </div>

          {/* AI */}
          <div className="flex gap-3">
            <div className="grid h-7 w-7 shrink-0 place-items-center rounded-full ai-gradient"><Sparkles className="h-3.5 w-3.5 text-white" /></div>
            <div className="min-w-0 flex-1 space-y-3">
              <div className="text-sm">Three deals show elevated Q3 risk. Slip probabilities below are computed from stage-velocity, engagement, and contact-stability signals over the last 30 days.</div>

              {/* Table card response */}
              <div className="overflow-hidden rounded-xl border border-border bg-card">
                <table className="w-full text-sm">
                  <thead className="bg-secondary/40 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <tr><th className="px-3 py-2 text-left">Deal</th><th className="px-3 py-2 text-left">Reason</th><th className="px-3 py-2 text-right">Slip</th></tr>
                  </thead>
                  <tbody>
                    {[
                      { d: "Airbus Sovereign Comms · €2.1M", r: "Champion changed roles 6d ago", s: 38 },
                      { d: "Nordea Branch managers · €360k", r: "Pricing pushback unresolved 9d", s: 24 },
                      { d: "Elering pilot → prod · €145k", r: "Pilot extended; engagement −41%", s: 22 },
                    ].map((r) => (
                      <tr key={r.d} className="border-t border-border/60">
                        <td className="px-3 py-2.5 font-medium">{r.d}</td>
                        <td className="px-3 py-2.5 text-muted-foreground">{r.r}</td>
                        <td className="px-3 py-2.5 text-right">
                          <span className="inline-flex items-center gap-1">
                            <div className="h-1 w-12 overflow-hidden rounded-full bg-secondary"><div className="h-full ai-gradient" style={{ width: `${r.s}%` }} /></div>
                            <span className="tnum text-xs">{r.s}%</span>
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Chart card */}
              <GlassCard className="p-4">
                <div className="mb-2 flex items-center gap-2 text-xs"><BarChart3 className="h-3 w-3 text-primary-glow" /><span className="font-medium">Engagement signal · last 30 days</span></div>
                <div className="flex h-24 items-end gap-1">
                  {[40, 38, 42, 45, 50, 48, 46, 44, 40, 38, 35, 33, 32, 30, 28, 26, 24, 22, 22, 21, 20, 20, 19, 18, 18, 17, 16, 15, 14, 13].map((v, i) => (
                    <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-primary to-primary-glow" style={{ height: `${v * 1.5}%` }} />
                  ))}
                </div>
              </GlassCard>

              <div className="text-sm text-muted-foreground">Want me to draft a re-engagement plan for Airbus, or schedule a TAM intervention?</div>

              <div className="flex gap-2">
                <button className="rounded-lg ai-gradient px-3 py-1.5 text-xs font-medium text-white">Draft plan</button>
                <button className="rounded-lg border border-border px-3 py-1.5 text-xs">Schedule TAM</button>
                <button className="rounded-lg border border-border px-3 py-1.5 text-xs">Open deals</button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-border p-4">
          <div className="mx-auto max-w-3xl rounded-2xl border border-border bg-card p-2">
            <textarea rows={2} placeholder="Ask anything about your CRM…" className="w-full resize-none bg-transparent p-2 text-sm focus:outline-none" />
            <div className="flex items-center justify-between p-1">
              <div className="text-[11px] text-muted-foreground">Grounded in: deals, accounts, activity, cases, forecast</div>
              <button className="inline-flex items-center gap-1.5 rounded-lg ai-gradient px-3 py-1.5 text-xs font-medium text-white"><Send className="h-3 w-3" /> Send</button>
            </div>
          </div>
        </div>
      </div>

      {/* Sources rail */}
      <aside className="border-l border-border bg-sidebar/40 p-4">
        <div className="mb-3 flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground"><Table2 className="h-3 w-3" /> Sources used</div>
        <div className="space-y-2 text-sm">
          {[
            { t: "Deal: Airbus Sovereign Comms", s: "Activity log, contact changes" },
            { t: "Deal: Nordea Branch managers", s: "Pricing thread, last email" },
            { t: "Deal: Elering pilot", s: "Engagement model, MDM telemetry" },
            { t: "Forecast snapshot Q3", s: "Generated 4 minutes ago" },
          ].map((s) => (
            <div key={s.t} className="rounded-lg border border-border bg-card p-3">
              <div className="text-xs font-medium">{s.t}</div>
              <div className="text-[11px] text-muted-foreground">{s.s}</div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-[11px] text-muted-foreground">Every answer can be inspected line-by-line. Click any source to open.</div>
      </aside>
    </div>
  );
}
