import { createFileRoute } from "@tanstack/react-router";
import { Plus, Filter, LayoutGrid, Table2, Sparkles } from "lucide-react";
import { deals, accounts, stages, fmt } from "../lib/seed";
import { AIChip, Avatar, Badge, SectionHeader } from "../components/primitives";

export const Route = createFileRoute("/pipeline")({
  head: () => ({
    meta: [
      { title: "Pipeline — HMD Secure CRM" },
      { name: "description", content: "Drag-and-drop kanban of every open deal, with AI risk surfaced inline." },
    ],
  }),
  component: Pipeline,
});

const stageColors: Record<string, string> = {
  Discovery: "bg-sky-500",
  Qualified: "bg-violet-500",
  Proposal: "bg-fuchsia-500",
  Negotiation: "bg-amber-500",
  "Closed Won": "bg-emerald-500",
};

function Pipeline() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader
        title="Pipeline"
        subtitle="7 active deals · €5.7M open · €11.5M total weighted"
        action={
          <div className="flex items-center gap-2">
            <div className="flex rounded-lg border border-border bg-card p-0.5">
              <button className="flex items-center gap-1.5 rounded-md bg-secondary px-2.5 py-1 text-xs"><LayoutGrid className="h-3.5 w-3.5" /> Board</button>
              <button className="flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs text-muted-foreground"><Table2 className="h-3.5 w-3.5" /> Table</button>
            </div>
            <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs"><Filter className="h-3.5 w-3.5" /> Filters</button>
            <button className="inline-flex items-center gap-1.5 rounded-lg ai-gradient px-3 py-1.5 text-xs font-medium text-white"><Plus className="h-3.5 w-3.5" /> New deal</button>
          </div>
        }
      />

      <div className="flex gap-2 overflow-x-auto pb-1">
        {["All deals", "My deals", "Closing this quarter", "At risk", "Renewals"].map((v, i) => (
          <button key={v} className={`shrink-0 rounded-full border px-3 py-1.5 text-xs ${i === 0 ? "border-primary/40 bg-accent text-foreground" : "border-border text-muted-foreground hover:bg-secondary"}`}>
            {v}
          </button>
        ))}
      </div>

      <div className="grid gap-4 overflow-x-auto md:grid-cols-3 lg:grid-cols-5">
        {stages.map((stage) => {
          const col = deals.filter((d) => d.stage === stage);
          const sum = col.reduce((s, d) => s + d.amount, 0);
          return (
            <div key={stage} className="flex min-w-[260px] flex-col rounded-2xl border border-border bg-sidebar/60 p-3">
              <div className="mb-3 flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${stageColors[stage]}`} />
                  <div className="text-sm font-medium">{stage}</div>
                </div>
                <div className="text-xs text-muted-foreground tnum">{col.length} · {fmt(sum)}</div>
              </div>
              <div className="flex flex-col gap-2">
                {col.map((d) => {
                  const acc = accounts.find((a) => a.id === d.account)!;
                  return (
                    <div key={d.id} className="group cursor-pointer rounded-xl border border-border bg-card p-3 transition hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-elegant">
                      <div className="flex items-start justify-between gap-2">
                        <div className="font-medium leading-tight">{d.name}</div>
                        {d.risk === "high" && <Badge tone="danger">High risk</Badge>}
                        {d.risk === "medium" && <Badge tone="warning">Watch</Badge>}
                      </div>
                      <div className="mt-2.5 flex items-center gap-2 text-xs text-muted-foreground">
                        <Avatar initials={acc.logo} hue={(acc.id.length * 37) % 360} size={20} />
                        <span className="truncate">{acc.name}</span>
                      </div>
                      <div className="mt-3 rounded-lg border border-primary/20 bg-accent/30 px-2.5 py-1.5">
                        <div className="flex items-center gap-1 text-[10px] ai-gradient-text">
                          <Sparkles className="h-2.5 w-2.5" /> AI
                        </div>
                        <div className="mt-0.5 text-xs leading-snug text-foreground/85">{d.aiSummary}</div>
                      </div>
                      <div className="mt-3 flex items-center justify-between">
                        <span className="font-display text-base font-semibold tnum">{fmt(d.amount)}</span>
                        <span className="text-[11px] text-muted-foreground">{d.closeDate.slice(5)}</span>
                      </div>
                    </div>
                  );
                })}
                <button className="mt-1 flex items-center justify-center gap-1 rounded-lg border border-dashed border-border py-2 text-xs text-muted-foreground hover:border-primary/40 hover:text-foreground">
                  <Plus className="h-3 w-3" /> Add deal
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
