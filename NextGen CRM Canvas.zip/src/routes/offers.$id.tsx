import { createFileRoute, useParams } from "@tanstack/react-router";
import { Send, Sparkles, ShieldCheck, Check, Clock, Plus, Image, Type, Table2 } from "lucide-react";
import { offerSample, fmt } from "../lib/seed";
import { Badge, GlassCard } from "../components/primitives";

export const Route = createFileRoute("/offers/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `Offer ${params.id} — HMD Secure CRM` },
      { name: "description", content: "Interactive web offer with live preview and approval chain." },
    ],
  }),
  component: Offer,
});

function Offer() {
  const o = offerSample;
  useParams({ from: "/offers/$id" });
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-xs text-muted-foreground">Offer · {o.id}</div>
          <h1 className="font-display text-2xl font-semibold">{o.title}</h1>
          <div className="mt-1 text-sm text-muted-foreground">For {o.account} · prepared by {o.prepared} · valid until {o.validUntil}</div>
        </div>
        <div className="flex items-center gap-2">
          <button className="rounded-lg border border-border px-3 py-1.5 text-xs">Preview as customer</button>
          <button className="rounded-lg border border-border px-3 py-1.5 text-xs">Download PDF</button>
          <button className="inline-flex items-center gap-1.5 rounded-lg ai-gradient px-3 py-1.5 text-xs font-medium text-white"><Send className="h-3.5 w-3.5" /> Send as web page</button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        {/* Preview */}
        <div className="space-y-4">
          <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-elegant">
            {/* Hero */}
            <div className="aurora relative overflow-hidden p-10 ai-gradient">
              <div className="aurora-bg absolute inset-0 opacity-50" />
              <div className="relative">
                <div className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-3 py-1 text-[11px] text-white backdrop-blur">
                  <ShieldCheck className="h-3 w-3" /> HMD Secure · proposal for {o.account}
                </div>
                <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight text-white">A secure mobility platform for your field engineers.</h2>
                <p className="mt-3 max-w-lg text-white/80">1,200 devices, fully managed, sovereign infrastructure, and a 24/7 TAM dedicated to your account.</p>
              </div>
            </div>

            {/* Sections */}
            <div className="space-y-8 p-8">
              <section>
                <h3 className="mb-4 font-display text-lg font-semibold">What you're getting</h3>
                <div className="grid gap-3 sm:grid-cols-2">
                  {o.lines.map((l) => (
                    <div key={l.sku} className="rounded-xl border border-border bg-background/40 p-4">
                      <div className="text-[11px] text-muted-foreground">{l.sku}</div>
                      <div className="font-medium">{l.name}</div>
                      <div className="mt-2 flex items-end justify-between">
                        <span className="text-xs text-muted-foreground">{l.qty.toLocaleString()} × {fmt(l.unit)}</span>
                        <span className="font-display text-lg font-semibold tnum">{fmt(l.total)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="mb-4 font-display text-lg font-semibold">Investment summary</h3>
                <div className="rounded-xl border border-border bg-background/40 p-5">
                  <div className="flex items-center justify-between border-b border-border pb-3">
                    <span className="text-sm text-muted-foreground">Subtotal</span>
                    <span className="font-medium tnum">{fmt(o.lines.reduce((s, l) => s + l.total, 0))}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-border py-3">
                    <span className="text-sm text-muted-foreground">Volume discount ({o.discount}%)</span>
                    <span className="font-medium tnum text-success">−{fmt(o.lines.reduce((s, l) => s + l.total, 0) * (o.discount / 100))}</span>
                  </div>
                  <div className="flex items-center justify-between pt-3">
                    <span className="font-medium">Total · 12 months</span>
                    <span className="font-display text-2xl font-semibold tnum ai-gradient-text">{fmt(o.total)}</span>
                  </div>
                </div>
              </section>

              <section className="rounded-xl border border-primary/30 bg-accent/20 p-5">
                <div className="text-sm font-medium">Accept and sign</div>
                <p className="mt-1 text-xs text-muted-foreground">A signed PDF will be sent to {o.account} legal and HMD Secure within 60 seconds.</p>
                <div className="mt-4 flex items-end gap-3">
                  <div className="flex-1 rounded-lg border-2 border-dashed border-border bg-background/60 p-5 text-center text-xs text-muted-foreground">Customer signature</div>
                  <button className="rounded-lg ai-gradient px-5 py-3 text-sm font-medium text-white shadow-elegant">Accept proposal</button>
                </div>
              </section>
            </div>
          </div>
        </div>

        {/* Editor sidebar */}
        <aside className="space-y-4">
          <GlassCard className="p-0">
            <div className="border-b border-border px-4 py-2.5 text-xs uppercase tracking-wider text-muted-foreground">Blocks</div>
            <div className="grid grid-cols-3 gap-2 p-3">
              {[
                { i: Type, l: "Text" }, { i: Image, l: "Hero" }, { i: Table2, l: "Pricing" },
                { i: ShieldCheck, l: "Compliance" }, { i: Sparkles, l: "AI block" }, { i: Plus, l: "More" },
              ].map((b) => {
                const Icon = b.i;
                return (
                  <button key={b.l} className="flex flex-col items-center gap-1 rounded-lg border border-border bg-background/40 px-2 py-3 text-[11px] hover:border-primary/40">
                    <Icon className="h-4 w-4 text-primary-glow" /><span>{b.l}</span>
                  </button>
                );
              })}
            </div>
          </GlassCard>

          <GlassCard className="p-0">
            <div className="border-b border-border px-4 py-2.5 text-xs uppercase tracking-wider text-muted-foreground">Approval chain</div>
            <div className="relative p-4">
              <div className="absolute left-[26px] top-6 bottom-6 w-px bg-border" />
              {o.approvals.map((a) => (
                <div key={a.step} className="relative mb-3 flex items-start gap-3 last:mb-0">
                  <div className={`relative z-10 grid h-6 w-6 shrink-0 place-items-center rounded-full ${
                    a.status === "done" ? "bg-success text-white" : a.status === "current" ? "ai-gradient text-white" : "border border-border bg-card text-muted-foreground"
                  }`}>
                    {a.status === "done" ? <Check className="h-3 w-3" /> : a.status === "current" ? <Sparkles className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium">{a.step}</div>
                    <div className="text-xs text-muted-foreground">{a.who}</div>
                    {a.status === "current" && (
                      <div className="mt-1.5 rounded-md border border-primary/30 bg-accent/30 p-2 text-[11px]">
                        <span className="ai-gradient-text font-medium">AI: </span>
                        Discount {o.discount}% is within your policy band (≤15%). Recommend approve.
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>

          <GlassCard>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Engagement</div>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Page views</span><span className="tnum">—</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Time on page</span><span className="tnum">—</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Sections viewed</span><span className="tnum">—</span></div>
            </div>
            <div className="mt-3 text-[11px] text-muted-foreground">Live once sent</div>
          </GlassCard>
        </aside>
      </div>
    </div>
  );
}
