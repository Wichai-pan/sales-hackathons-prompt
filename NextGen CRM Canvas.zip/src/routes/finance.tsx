import { createFileRoute } from "@tanstack/react-router";
import { Download, AlertTriangle } from "lucide-react";
import { fmt } from "../lib/seed";
import { Badge, GlassCard, SectionHeader, SparkLine } from "../components/primitives";

export const Route = createFileRoute("/finance")({
  head: () => ({
    meta: [
      { title: "Finance — HMD Secure CRM" },
      { name: "description", content: "Revenue, approved discounts, AR aging and contract expirations." },
    ],
  }),
  component: Finance,
});

function Finance() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader
        title="Finance"
        subtitle="EMEA · Q3 2026 · close cycle day 14 of 90"
        action={<button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs"><Download className="h-3.5 w-3.5" /> Export close pack</button>}
      />

      <div className="grid gap-4 lg:grid-cols-4">
        {[
          { l: "Recognized revenue", v: fmt(1840000), d: "+12%", t: [20, 28, 34, 40, 46, 52, 60, 68] },
          { l: "Bookings (signed)", v: fmt(2480000), d: "+18%", t: [30, 40, 50, 55, 60, 70, 80, 90] },
          { l: "Approved discount $", v: fmt(312000), d: "−4%", t: [40, 36, 38, 34, 33, 30, 32, 28] },
          { l: "Gross margin", v: "61%", d: "+1.2pt", t: [55, 56, 58, 59, 60, 60, 61, 61] },
        ].map(k => (
          <GlassCard key={k.l}>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{k.l}</div>
            <div className="mt-2 flex items-end justify-between">
              <div className="font-display text-3xl font-semibold tnum">{k.v}</div>
              <SparkLine data={k.t} />
            </div>
            <div className="mt-1 text-xs text-success">{k.d} QoQ</div>
          </GlassCard>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <GlassCard className="p-0">
          <div className="border-b border-border px-5 py-3 font-medium text-sm">AR aging</div>
          <div className="p-5 space-y-3">
            {[
              { label: "Current", v: 1840000, c: "bg-success" },
              { label: "1-30 days", v: 620000, c: "bg-info" },
              { label: "31-60 days", v: 240000, c: "bg-warning" },
              { label: "61-90 days", v: 95000, c: "bg-destructive/80" },
              { label: "90+ days", v: 28000, c: "bg-destructive" },
            ].map((r) => (
              <div key={r.label} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{r.label}</span>
                  <span className="tnum font-medium">{fmt(r.v)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-secondary">
                  <div className={`h-full rounded-full ${r.c}`} style={{ width: `${(r.v / 1840000) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-0">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div className="font-medium text-sm">Contracts expiring soon</div>
            <Badge tone="warning">5 in 60d</Badge>
          </div>
          <table className="w-full text-sm">
            <thead className="text-xs uppercase tracking-wider text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-5 py-2 text-left font-medium">Account</th>
                <th className="px-3 py-2 text-left font-medium">Expires</th>
                <th className="px-3 py-2 text-right font-medium">ARR</th>
                <th className="px-5 py-2 text-left font-medium">Risk</th>
              </tr>
            </thead>
            <tbody>
              {[
                { a: "Deutsche Bahn", d: "2026-07-30", v: 1840000, r: "low" },
                { a: "Nordea", d: "2026-08-12", v: 920000, r: "medium" },
                { a: "Telia Company", d: "2026-08-22", v: 2110000, r: "low" },
                { a: "Elering", d: "2026-09-04", v: 280000, r: "high" },
                { a: "Airbus Defence", d: "2026-09-18", v: 1520000, r: "medium" },
              ].map((c) => (
                <tr key={c.a} className="border-b border-border/60 last:border-0">
                  <td className="px-5 py-2.5 font-medium">{c.a}</td>
                  <td className="px-3 py-2.5 text-muted-foreground">{c.d}</td>
                  <td className="px-3 py-2.5 text-right tnum">{fmt(c.v)}</td>
                  <td className="px-5 py-2.5">
                    <Badge tone={c.r === "high" ? "danger" : c.r === "medium" ? "warning" : "success"}>{c.r}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </GlassCard>
      </div>

      <GlassCard className="flex items-center gap-4 border-warning/40 bg-warning/5 p-5">
        <div className="grid h-10 w-10 place-items-center rounded-lg bg-warning/20"><AlertTriangle className="h-5 w-5 text-warning" /></div>
        <div className="flex-1">
          <div className="font-medium">3 discounts approved in the last 7 days exceed policy band</div>
          <div className="text-sm text-muted-foreground">Review with Sales Manager before close. Estimated margin impact: −€42k.</div>
        </div>
        <button className="rounded-lg border border-border bg-card px-3 py-1.5 text-xs">Review</button>
      </GlassCard>
    </div>
  );
}
