import { createFileRoute } from "@tanstack/react-router";
import { Mail, Sparkles, Wand2, ArrowRight, CheckCircle2, Clock, AlertTriangle } from "lucide-react";
import { kpis, nbAs, deals, accounts, fmt } from "../lib/seed";
import { AIChip, Avatar, Badge, GlassCard, KpiTile, SectionHeader } from "../components/primitives";

export const Route = createFileRoute("/rep")({
  head: () => ({
    meta: [
      { title: "Dashboard — Sales Rep · HMD Secure CRM" },
      { name: "description", content: "Sales Rep workspace: AI intake, next best actions, pipeline at a glance." },
    ],
  }),
  component: Rep,
});

function Rep() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader
        title="Good morning, Sofia ✨"
        subtitle="3 deals progressed yesterday · 2 risks need your attention · 1 renewal due in 47 days."
        action={
          <button className="inline-flex items-center gap-2 rounded-lg ai-gradient px-4 py-2 text-sm font-medium text-white shadow-elegant">
            <Sparkles className="h-4 w-4" /> Daily brief
          </button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k) => <KpiTile key={k.label} {...k} />)}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        {/* AI Intake */}
        <GlassCard className="overflow-hidden p-0">
          <div className="flex items-center justify-between border-b border-border bg-gradient-to-r from-accent/40 to-transparent px-5 py-4">
            <div className="flex items-center gap-2">
              <div className="grid h-8 w-8 place-items-center rounded-lg ai-gradient"><Wand2 className="h-4 w-4 text-white" /></div>
              <div>
                <div className="font-display text-sm font-semibold">AI-assisted intake</div>
                <div className="text-xs text-muted-foreground">Paste an inbound email → structured deal in seconds</div>
              </div>
            </div>
            <AIChip>Featherless · grounded</AIChip>
          </div>
          <div className="grid gap-0 md:grid-cols-2">
            <div className="border-r border-border p-5">
              <div className="mb-2 flex items-center gap-2 text-xs text-muted-foreground"><Mail className="h-3 w-3" /> Inbound email</div>
              <textarea
                rows={10}
                defaultValue={`From: Mira Lehto <mira.lehto@nordea.com>\nSubject: Secure devices for branch managers Q3\n\nHi Sofia,\n\nFollowing our chat at Slush, we'd like to move forward with ~1,800 secure devices for our branch managers across Nordics. Looking at a 12-month MDM contract with VPN. Budget approval is in motion — would like a proposal by end of next week.\n\nBest,\nMira`}
                className="w-full resize-none rounded-lg border border-border bg-background/50 p-3 font-mono text-[12px] leading-relaxed text-foreground focus:border-primary focus:outline-none"
              />
              <button className="mt-3 inline-flex items-center gap-2 rounded-lg border border-primary/40 bg-accent/60 px-3 py-1.5 text-xs font-medium ai-gradient-text">
                <Sparkles className="h-3 w-3" /> Parse with AI
              </button>
            </div>
            <div className="p-5">
              <div className="mb-3 flex items-center justify-between">
                <div className="text-xs text-muted-foreground">AI-extracted draft</div>
                <Badge tone="success">92% confidence</Badge>
              </div>
              <div className="space-y-3 text-sm">
                {[
                  ["Account", "Nordea"],
                  ["Contact", "Mira Lehto · CIO Office"],
                  ["Use case", "Branch managers — Nordics"],
                  ["Volume", "≈ 1,800 devices"],
                  ["Add-ons", "MDM (12m) · EU VPN"],
                  ["Timeline", "Proposal due in ≤ 10 days"],
                  ["Est. value", fmt(540000)],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between rounded-lg border border-border bg-background/40 px-3 py-2">
                    <span className="text-xs text-muted-foreground">{k}</span>
                    <span className="font-medium">{v}</span>
                  </div>
                ))}
              </div>
              <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg ai-gradient py-2.5 text-sm font-medium text-white">
                Create deal & contact <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </GlassCard>

        {/* NBA */}
        <GlassCard className="p-0">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <div>
              <div className="font-display text-sm font-semibold">Today's next best actions</div>
              <div className="text-xs text-muted-foreground">Ranked by AI based on signal & deadlines</div>
            </div>
            <AIChip>5 new</AIChip>
          </div>
          <div className="divide-y divide-border">
            {nbAs.map((a) => (
              <div key={a.id} className="group flex items-start gap-3 px-5 py-3.5 hover:bg-secondary/40">
                <div className={`mt-1 h-2 w-2 shrink-0 rounded-full ${a.urgency === "high" ? "bg-destructive" : a.urgency === "medium" ? "bg-warning" : "bg-info"}`} />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium leading-tight">{a.title}</div>
                  <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="truncate">{a.account}</span>
                    <span>·</span>
                    <span className="italic">{a.reason}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><Clock className="h-3 w-3" />{a.eta}</div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Mini pipeline */}
      <GlassCard className="p-0">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="font-display text-sm font-semibold">Your pipeline · live</div>
          <div className="flex gap-2 text-xs">
            <Badge>7 active</Badge>
            <Badge tone="success">€5.7M open</Badge>
            <Badge tone="warning">2 at risk</Badge>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase tracking-wider text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-5 py-2.5 text-left font-medium">Deal</th>
                <th className="px-3 py-2.5 text-left font-medium">Account</th>
                <th className="px-3 py-2.5 text-left font-medium">Stage</th>
                <th className="px-3 py-2.5 text-right font-medium">Amount</th>
                <th className="px-3 py-2.5 text-left font-medium">AI Signal</th>
                <th className="px-5 py-2.5 text-right font-medium">Confidence</th>
              </tr>
            </thead>
            <tbody>
              {deals.filter(d => d.owner === "sofia").map((d) => {
                const acc = accounts.find(a => a.id === d.account)!;
                return (
                  <tr key={d.id} className="border-b border-border/60 last:border-0 hover:bg-secondary/30">
                    <td className="px-5 py-3 font-medium">{d.name}</td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <Avatar initials={acc.logo} hue={(acc.id.length * 37) % 360} size={22} />
                        <span className="text-muted-foreground">{acc.name}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3"><Badge tone={d.stage === "Closed Won" ? "success" : d.stage === "Negotiation" ? "primary" : "default"}>{d.stage}</Badge></td>
                    <td className="px-3 py-3 text-right font-medium tnum">{fmt(d.amount)}</td>
                    <td className="px-3 py-3 text-xs text-muted-foreground italic">{d.aiSummary}</td>
                    <td className="px-5 py-3 text-right">
                      <div className="inline-flex items-center gap-2">
                        <div className="h-1.5 w-16 overflow-hidden rounded-full bg-secondary">
                          <div className={`h-full rounded-full ${d.confidence > 70 ? "bg-success" : d.confidence > 50 ? "bg-warning" : "bg-destructive"}`} style={{ width: `${d.confidence}%` }} />
                        </div>
                        <span className="tnum text-xs">{d.confidence}</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}
