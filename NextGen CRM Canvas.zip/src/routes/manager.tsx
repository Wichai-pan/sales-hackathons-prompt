import { createFileRoute } from "@tanstack/react-router";
import { Trophy, Sparkles, Check, X } from "lucide-react";
import { deals, accounts, fmt } from "../lib/seed";
import { AIChip, Avatar, Badge, GlassCard, SectionHeader, SparkLine } from "../components/primitives";

export const Route = createFileRoute("/manager")({
  head: () => ({
    meta: [
      { title: "Manager — HMD Secure CRM" },
      { name: "description", content: "Sales manager overview: team performance, coverage, and approvals." },
    ],
  }),
  component: Manager,
});

const team = [
  { name: "Sofia Lindqvist", hue: 280, quota: 100, attain: 84, deals: 7, trend: [40, 50, 55, 62, 70, 75, 80, 84] },
  { name: "Henri Aalto", hue: 200, quota: 100, attain: 112, deals: 5, trend: [50, 60, 70, 80, 95, 105, 108, 112] },
  { name: "Léa Dubois", hue: 320, quota: 100, attain: 67, deals: 4, trend: [20, 28, 35, 42, 48, 55, 60, 67] },
  { name: "Karl Berg", hue: 150, quota: 100, attain: 92, deals: 6, trend: [40, 55, 60, 68, 75, 82, 88, 92] },
];

export function Manager() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader title="Sales Manager · EMEA" subtitle="4 reps · 22 active deals · 84% team attainment" />

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <GlassCard className="p-0">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div className="flex items-center gap-2 font-medium text-sm"><Trophy className="h-4 w-4 text-warning" /> Team leaderboard · Q3</div>
            <AIChip>AI ranked by impact</AIChip>
          </div>
          <div className="divide-y divide-border">
            {team.sort((a, b) => b.attain - a.attain).map((m, i) => (
              <div key={m.name} className="flex items-center gap-4 px-5 py-3">
                <div className="w-5 text-center font-display text-sm font-semibold text-muted-foreground tnum">{i + 1}</div>
                <Avatar initials={m.name.split(" ").map(x=>x[0]).join("")} hue={m.hue} size={36} />
                <div className="min-w-0 flex-1">
                  <div className="font-medium leading-tight">{m.name}</div>
                  <div className="text-xs text-muted-foreground">{m.deals} active deals</div>
                </div>
                <SparkLine data={m.trend} />
                <div className="w-40">
                  <div className="flex items-center justify-between text-xs"><span className="text-muted-foreground">{m.attain}%</span><span className="text-muted-foreground">of quota</span></div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
                    <div className={`h-full rounded-full ${m.attain >= 100 ? "bg-success" : m.attain >= 80 ? "ai-gradient" : "bg-warning"}`} style={{ width: `${Math.min(m.attain, 130)}%` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-0">
          <div className="border-b border-border px-5 py-3 font-medium text-sm">Pipeline coverage heatmap</div>
          <div className="p-5">
            <div className="mb-2 grid grid-cols-6 gap-1 text-[10px] text-muted-foreground">
              <div />
              {["Disc", "Qual", "Prop", "Neg", "Won"].map(s => <div key={s} className="text-center">{s}</div>)}
            </div>
            {team.map((m) => (
              <div key={m.name} className="grid grid-cols-6 gap-1 mb-1 items-center">
                <div className="truncate text-xs">{m.name.split(" ")[0]}</div>
                {[0.3, 0.6, 0.85, 0.5, 0.4].map((v, i) => (
                  <div key={i} className="h-7 rounded" style={{ background: `color-mix(in oklab, var(--color-primary) ${v * 70}%, transparent)` }} />
                ))}
              </div>
            ))}
            <div className="mt-4 flex items-center justify-between text-[10px] text-muted-foreground">
              <span>Less</span>
              <div className="flex gap-0.5">
                {[15, 30, 45, 60, 75].map(v => <div key={v} className="h-2 w-4 rounded" style={{ background: `color-mix(in oklab, var(--color-primary) ${v}%, transparent)` }} />)}
              </div>
              <span>More</span>
            </div>
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-0">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <div className="font-medium text-sm">Approval queue · discounts</div>
          <Badge tone="warning">3 pending</Badge>
        </div>
        <div className="divide-y divide-border">
          {deals.slice(0, 3).map((d, i) => {
            const acc = accounts.find(a => a.id === d.account)!;
            const discount = [12, 18, 8][i];
            const rec = discount <= 15;
            return (
              <div key={d.id} className="flex items-start gap-4 px-5 py-4">
                <Avatar initials={acc.logo} hue={(acc.id.length * 37) % 360} size={36} />
                <div className="min-w-0 flex-1">
                  <div className="font-medium">{d.name}</div>
                  <div className="text-xs text-muted-foreground">{acc.name} · requested by Sofia L.</div>
                  <div className="mt-2 rounded-lg border border-primary/30 bg-accent/20 p-2 text-xs">
                    <span className="ai-gradient-text font-medium"><Sparkles className="mr-1 inline h-3 w-3" />AI: </span>
                    {rec
                      ? `Discount ${discount}% within policy band. Margin remains healthy at 62%. Recommend approve.`
                      : `Discount ${discount}% exceeds policy band (15%). Margin drops to 48%. Recommend negotiate to 14%.`}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-display text-lg font-semibold tnum">{fmt(d.amount)}</div>
                  <div className="text-xs text-muted-foreground">−{discount}% discount</div>
                </div>
                <div className="flex gap-2">
                  <button className={`inline-flex items-center gap-1 rounded-lg px-3 py-2 text-xs font-medium text-white ${rec ? "ai-gradient" : "bg-secondary text-foreground"}`}><Check className="h-3 w-3" /> Approve</button>
                  <button className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-2 text-xs"><X className="h-3 w-3" /> Reject</button>
                </div>
              </div>
            );
          })}
        </div>
      </GlassCard>
    </div>
  );
}

export default Manager;
