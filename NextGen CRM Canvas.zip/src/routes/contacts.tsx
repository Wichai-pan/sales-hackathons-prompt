import { createFileRoute, Link } from "@tanstack/react-router";
import { Filter, Plus, Search, Sparkles, Download } from "lucide-react";
import { accounts, fmt } from "../lib/seed";
import { AIChip, Avatar, Badge, HealthRing, SectionHeader } from "../components/primitives";

export const Route = createFileRoute("/contacts")({
  head: () => ({
    meta: [
      { title: "Accounts — HMD Secure CRM" },
      { name: "description", content: "All enterprise accounts in one calm, dense table — Attio-style." },
    ],
  }),
  component: Contacts,
});

function Contacts() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader
        title="Accounts"
        subtitle="6 of 124 enterprise accounts · 21,040 devices under management"
        action={
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs"><Download className="h-3.5 w-3.5" /> Export</button>
            <button className="inline-flex items-center gap-1.5 rounded-lg ai-gradient px-3 py-1.5 text-xs font-medium text-white"><Plus className="h-3.5 w-3.5" /> Add account</button>
          </div>
        }
      />

      <div className="flex gap-6">
        {/* Faceted filters */}
        <aside className="hidden w-56 shrink-0 lg:block">
          <div className="sticky top-20 space-y-5">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
              <input placeholder="Filter…" className="h-8 w-full rounded-md border border-border bg-card pl-8 pr-2 text-xs focus:border-primary focus:outline-none" />
            </div>
            {[
              { title: "Industry", items: ["Banking", "Transport", "Energy", "Telecom", "Aerospace", "Utilities"] },
              { title: "Region", items: ["DE", "FI", "FR", "SE", "EE"] },
              { title: "Owner", items: ["Sofia Lindqvist", "Timo Virtanen"] },
              { title: "Health", items: ["Healthy (80+)", "At risk (60-79)", "Critical (<60)"] },
            ].map((g) => (
              <div key={g.title}>
                <div className="mb-1.5 flex items-center justify-between text-[11px] uppercase tracking-wider text-muted-foreground">
                  <span>{g.title}</span><Filter className="h-3 w-3" />
                </div>
                <div className="space-y-1">
                  {g.items.map((it) => (
                    <label key={it} className="flex items-center gap-2 rounded-md px-2 py-1 text-xs hover:bg-secondary">
                      <input type="checkbox" className="h-3 w-3 accent-[var(--color-primary)]" />
                      <span className="truncate">{it}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
            <button className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-primary/30 bg-accent/40 py-2 text-xs ai-gradient-text">
              <Sparkles className="h-3 w-3" /> Save AI view
            </button>
          </div>
        </aside>

        {/* Table */}
        <div className="flex-1 overflow-hidden rounded-2xl border border-border bg-card">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/30 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  {["Account", "Industry", "Region", "Owner", "Devices", "ARR", "Health", "AI signal"].map((h) => (
                    <th key={h} className="whitespace-nowrap px-4 py-3 text-left font-medium first:pl-5 last:pr-5">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {accounts.map((a) => (
                  <tr key={a.id} className="border-t border-border/60 hover:bg-secondary/30">
                    <td className="px-4 py-3 pl-5">
                      <Link to="/accounts/$id" params={{ id: a.id }} className="flex items-center gap-3">
                        <Avatar initials={a.logo} hue={(a.id.length * 37) % 360} size={30} />
                        <div>
                          <div className="font-medium">{a.name}</div>
                          <div className="text-[11px] text-muted-foreground">{a.id}</div>
                        </div>
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{a.industry}</td>
                    <td className="px-4 py-3"><Badge>{a.region}</Badge></td>
                    <td className="px-4 py-3 text-muted-foreground">{a.owner === "sofia" ? "Sofia L." : "Timo V."}</td>
                    <td className="px-4 py-3 tnum">{a.devices.toLocaleString()}</td>
                    <td className="px-4 py-3 font-medium tnum">{fmt(a.arr)}</td>
                    <td className="px-4 py-3"><HealthRing value={a.health} size={36} /></td>
                    <td className="px-4 py-3 pr-5">
                      {a.health < 70 ? <AIChip>Engagement dropping</AIChip> : a.health > 85 ? <Badge tone="success">Expansion ready</Badge> : <Badge>Stable</Badge>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
