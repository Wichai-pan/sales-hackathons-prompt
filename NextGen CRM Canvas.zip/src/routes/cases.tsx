import { createFileRoute } from "@tanstack/react-router";
import { Search, Filter, Sparkles, Send, Paperclip, Smartphone, Clock, ShieldAlert } from "lucide-react";
import { useState } from "react";
import { cases } from "../lib/seed";
import { AIChip, Avatar, Badge, SectionHeader } from "../components/primitives";

export const Route = createFileRoute("/cases")({
  head: () => ({
    meta: [
      { title: "Cases — HMD Secure CRM" },
      { name: "description", content: "TAM case management with AI-suggested replies — Intercom-style three-pane." },
    ],
  }),
  component: Cases,
});

function Cases() {
  const [active, setActive] = useState(cases[0].id);
  const c = cases.find((x) => x.id === active) ?? cases[0];
  return (
    <div className="p-6 lg:p-8 space-y-6">
      <SectionHeader title="Cases" subtitle="5 open · 2 P1 · avg first response 14m" />
      <div className="grid h-[calc(100vh-220px)] grid-cols-[280px_1fr_320px] gap-0 overflow-hidden rounded-2xl border border-border bg-card">
        {/* List */}
        <div className="flex flex-col border-r border-border">
          <div className="border-b border-border p-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
              <input placeholder="Search cases" className="h-8 w-full rounded-md border border-border bg-background/50 pl-8 pr-2 text-xs focus:border-primary focus:outline-none" />
            </div>
            <div className="mt-2 flex gap-1">
              {["All", "Open", "P1", "Mine"].map((t, i) => (
                <button key={t} className={`rounded-md px-2 py-0.5 text-[11px] ${i === 0 ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-secondary"}`}>{t}</button>
              ))}
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {cases.map((k) => (
              <button key={k.id} onClick={() => setActive(k.id)} className={`w-full border-b border-border/60 px-3 py-3 text-left transition ${active === k.id ? "bg-accent/40" : "hover:bg-secondary/40"}`}>
                <div className="flex items-center justify-between gap-2">
                  <Badge tone={k.priority === "P1" ? "danger" : k.priority === "P2" ? "warning" : "default"}>{k.priority}</Badge>
                  <span className="text-[10px] text-muted-foreground">{k.sla}</span>
                </div>
                <div className="mt-1.5 text-sm font-medium leading-tight">{k.subject}</div>
                <div className="text-[11px] text-muted-foreground">{k.account}</div>
                <div className="mt-1 truncate text-[11px] text-muted-foreground/80">{k.lastMsg}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Thread */}
        <div className="flex min-w-0 flex-col">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <div>
              <div className="text-sm font-medium">{c.subject}</div>
              <div className="text-[11px] text-muted-foreground">{c.account} · case {c.id}</div>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={c.priority === "P1" ? "danger" : "warning"}>{c.priority}</Badge>
              <Badge tone="info">{c.status}</Badge>
              <button className="rounded-md border border-border px-2 py-1 text-xs hover:bg-secondary">Reassign</button>
              <button className="rounded-md ai-gradient px-2 py-1 text-xs text-white">Resolve</button>
            </div>
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto p-5">
            {/* Customer */}
            <div className="flex items-start gap-3">
              <Avatar initials="MB" hue={280} size={32} />
              <div className="max-w-xl rounded-2xl rounded-tl-sm bg-secondary/40 p-3">
                <div className="mb-1 text-[11px] text-muted-foreground">Maria Brandt · Deutsche Bahn · 11:42</div>
                <div className="text-sm">Hi team — we're seeing MDM enrollment failures on iOS 19.2 across the conductor fleet (~1,200 devices). Started after this morning's rollout. Can you take a look ASAP?</div>
              </div>
            </div>
            {/* AI suggested */}
            <div className="flex items-start gap-3">
              <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full ai-gradient"><Sparkles className="h-4 w-4 text-white" /></div>
              <div className="max-w-xl rounded-2xl rounded-tl-sm border border-primary/30 bg-accent/30 p-3">
                <div className="mb-1 flex items-center gap-2 text-[11px] ai-gradient-text">AI suggested context</div>
                <div className="text-sm">3 similar cases resolved last week. Root cause: the enrollment profile must include the new <code className="rounded bg-background/60 px-1 py-0.5 font-mono text-[11px]">aps-token-v2</code> claim. Suggest reply with patched profile + rollback playbook.</div>
                <button className="mt-2 rounded-md border border-primary/40 bg-background/40 px-2 py-1 text-[11px] ai-gradient-text">Use as draft reply</button>
              </div>
            </div>
            {/* TAM */}
            <div className="flex items-start gap-3 justify-end">
              <div className="max-w-xl rounded-2xl rounded-tr-sm ai-gradient p-3 text-white">
                <div className="mb-1 text-[11px] opacity-80">Timo Virtanen · 11:48</div>
                <div className="text-sm">Hi Maria — confirmed on our side, related to APS token v2 in iOS 19.2. Sending patched profile in 5 min + rollback script if you need to revert before then.</div>
              </div>
              <Avatar initials="TV" hue={200} size={32} />
            </div>
            {/* Internal note */}
            <div className="ml-11 rounded-xl border border-warning/40 bg-warning/10 p-3 text-xs text-warning">
              <div className="mb-1 font-medium">Internal note</div>
              Paged platform team — fix is staged in v19.2.1. ETA tomorrow EU morning.
            </div>
          </div>
          <div className="border-t border-border p-3">
            <div className="rounded-xl border border-border bg-background/50 p-2">
              <div className="flex items-center gap-1 px-1 pb-1 text-[10px] text-muted-foreground">
                <button className="rounded px-1.5 py-0.5 hover:bg-secondary">Reply</button>
                <button className="rounded px-1.5 py-0.5 hover:bg-secondary">Internal note</button>
                <button className="ml-auto inline-flex items-center gap-1 rounded px-1.5 py-0.5 ai-gradient-text"><Sparkles className="h-3 w-3" /> Draft with AI</button>
              </div>
              <textarea rows={2} placeholder="Type a reply… (⌘↵ to send)" className="w-full resize-none bg-transparent p-1 text-sm focus:outline-none" />
              <div className="flex items-center justify-between p-1">
                <button className="grid h-7 w-7 place-items-center rounded-md hover:bg-secondary"><Paperclip className="h-3.5 w-3.5" /></button>
                <button className="inline-flex items-center gap-1.5 rounded-md ai-gradient px-3 py-1 text-xs font-medium text-white"><Send className="h-3 w-3" /> Send</button>
              </div>
            </div>
          </div>
        </div>

        {/* Context */}
        <div className="space-y-4 border-l border-border bg-sidebar/40 p-4 overflow-y-auto">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">SLA</div>
            <div className="mt-1 flex items-center gap-2">
              <Clock className="h-4 w-4 text-warning" />
              <div className="font-display text-lg font-semibold tnum">{c.sla}</div>
              <span className="text-[11px] text-muted-foreground">until breach</span>
            </div>
            <div className="mt-2 h-1 overflow-hidden rounded-full bg-secondary">
              <div className="h-full w-[28%] rounded-full bg-warning" />
            </div>
          </div>
          <div>
            <div className="mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">Customer</div>
            <div className="rounded-xl border border-border bg-card p-3">
              <div className="flex items-center gap-2">
                <Avatar initials="DB" hue={120} size={28} />
                <div>
                  <div className="text-sm font-medium">{c.account}</div>
                  <div className="text-[11px] text-muted-foreground">Banking · DE</div>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-md bg-background/40 p-2"><div className="text-muted-foreground">Devices</div><div className="font-medium tnum">4,200</div></div>
                <div className="rounded-md bg-background/40 p-2"><div className="text-muted-foreground">ARR</div><div className="font-medium tnum">€1.8M</div></div>
              </div>
            </div>
          </div>
          <div>
            <div className="mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">Affected devices</div>
            {[
              { name: "HMD Pro 512", v: "iOS 19.2", n: 1200 },
              { name: "HMD Pro 256", v: "iOS 19.2", n: 320 },
            ].map((d) => (
              <div key={d.name} className="mb-2 flex items-center gap-2 rounded-lg border border-border bg-card p-2 text-xs">
                <Smartphone className="h-3.5 w-3.5 text-primary-glow" />
                <div className="flex-1"><div className="font-medium">{d.name}</div><div className="text-muted-foreground">{d.v}</div></div>
                <span className="tnum">{d.n}</span>
              </div>
            ))}
          </div>
          <div>
            <div className="mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">Linked</div>
            <div className="rounded-lg border border-border bg-card p-2 text-xs">
              <div className="flex items-center gap-2"><ShieldAlert className="h-3.5 w-3.5 text-warning" /><span className="font-medium">Deal: DB — Cross-border ops</span></div>
              <div className="mt-0.5 text-muted-foreground">Proposal stage · €620k</div>
            </div>
          </div>
          <AIChip>2 similar cases this week</AIChip>
        </div>
      </div>
    </div>
  );
}
