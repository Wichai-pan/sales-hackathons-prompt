// Mock data for HMD Secure CRM design preview
export type Role = "rep" | "tam" | "manager" | "finance";

export const users = [
  { id: "sofia", name: "Sofia Lindqvist", role: "rep" as Role, title: "Sales Rep — Nordics", avatar: "SL", hue: 280 },
  { id: "timo", name: "Timo Virtanen", role: "tam" as Role, title: "Technical Account Manager", avatar: "TV", hue: 200 },
  { id: "mira", name: "Mira Schneider", role: "manager" as Role, title: "Sales Manager — EMEA", avatar: "MS", hue: 320 },
  { id: "fiona", name: "Fiona O'Connell", role: "finance" as Role, title: "Finance Lead", avatar: "FO", hue: 150 },
];

export const accounts = [
  { id: "deutschebank", name: "Deutsche Bahn", logo: "DB", industry: "Transport", region: "DE", devices: 4200, health: 86, owner: "sofia", arr: 1840000 },
  { id: "nordea", name: "Nordea", logo: "ND", industry: "Banking", region: "FI", devices: 1800, health: 72, owner: "sofia", arr: 920000 },
  { id: "siemens", name: "Siemens Energy", logo: "SE", industry: "Energy", region: "DE", devices: 6300, health: 91, owner: "sofia", arr: 2740000 },
  { id: "airbus", name: "Airbus Defence", logo: "AB", industry: "Aerospace", region: "FR", devices: 3100, health: 64, owner: "timo", arr: 1520000 },
  { id: "telia", name: "Telia Company", logo: "TC", industry: "Telecom", region: "SE", devices: 5200, health: 78, owner: "sofia", arr: 2110000 },
  { id: "elering", name: "Elering", logo: "EL", industry: "Utilities", region: "EE", devices: 420, health: 88, owner: "timo", arr: 280000 },
];

export const stages = ["Discovery", "Qualified", "Proposal", "Negotiation", "Closed Won"] as const;

export const deals = [
  { id: "d1", name: "DB — Conductor fleet renewal", account: "deutschebank", stage: "Negotiation", amount: 840000, closeDate: "2026-07-12", owner: "sofia", risk: "low", aiSummary: "Champion confirmed, legal review in progress.", confidence: 78 },
  { id: "d2", name: "Nordea — Branch managers Q3", account: "nordea", stage: "Proposal", amount: 360000, closeDate: "2026-08-30", owner: "sofia", risk: "medium", aiSummary: "Pricing pushback on premium tier; suggest tiered offer.", confidence: 55 },
  { id: "d3", name: "Siemens — Field engineers expansion", account: "siemens", stage: "Qualified", amount: 1200000, closeDate: "2026-09-15", owner: "sofia", risk: "low", aiSummary: "Multi-region rollout, awaiting security review.", confidence: 62 },
  { id: "d4", name: "Airbus — Sovereign Comms", account: "airbus", stage: "Negotiation", amount: 2100000, closeDate: "2026-07-28", owner: "timo", risk: "high", aiSummary: "Procurement reshuffle — re-confirm sponsor by Friday.", confidence: 41 },
  { id: "d5", name: "Telia — Executive devices Q3", account: "telia", stage: "Closed Won", amount: 480000, closeDate: "2026-06-04", owner: "sofia", risk: "low", aiSummary: "Signed. TAM handoff scheduled.", confidence: 100 },
  { id: "d6", name: "Elering — Pilot to production", account: "elering", stage: "Discovery", amount: 145000, closeDate: "2026-10-20", owner: "timo", risk: "medium", aiSummary: "Pilot extended 30 days; need exec briefing.", confidence: 35 },
  { id: "d7", name: "DB — Cross-border ops", account: "deutschebank", stage: "Proposal", amount: 620000, closeDate: "2026-08-10", owner: "sofia", risk: "low", aiSummary: "Tied to D1; bundle discount being modeled.", confidence: 68 },
];

export const nbAs = [
  { id: 1, title: "Follow up on Airbus procurement reshuffle", account: "Airbus Defence", reason: "Champion changed teams 6 days ago", urgency: "high", eta: "Today" },
  { id: 2, title: "Send pricing sheet to Nordea", account: "Nordea", reason: "Promised by EoW in last call note", urgency: "medium", eta: "Today" },
  { id: 3, title: "Schedule security review with Siemens", account: "Siemens Energy", reason: "Stage progress blocked 9 days", urgency: "high", eta: "Tomorrow" },
  { id: 4, title: "Renewal motion for DB cross-border", account: "Deutsche Bahn", reason: "Contract renews in 47 days", urgency: "low", eta: "This week" },
  { id: 5, title: "Health check call — Elering", account: "Elering", reason: "Pilot extended; engagement signal dropping", urgency: "medium", eta: "Wed" },
];

export const cases = [
  { id: "c1", subject: "MDM enrollment failing on iOS 19.2", account: "Deutsche Bahn", status: "Open", priority: "P1", sla: "2h 14m", owner: "timo", lastMsg: "We rolled out the affected build to 1200 devices..." },
  { id: "c2", subject: "Secure boot certificate rotation", account: "Siemens Energy", status: "In Progress", priority: "P2", sla: "8h 02m", owner: "timo", lastMsg: "Rotation script staged; awaiting maintenance window." },
  { id: "c3", subject: "VPN profile push delayed", account: "Nordea", status: "Open", priority: "P2", sla: "5h 41m", owner: "timo", lastMsg: "Seeing intermittent failures on the Stockholm cluster." },
  { id: "c4", subject: "Bulk provisioning API rate limits", account: "Telia Company", status: "Resolved", priority: "P3", sla: "—", owner: "timo", lastMsg: "Rate limit raised to 50 rps. Closing." },
  { id: "c5", subject: "Compliance export for ISO 27001 audit", account: "Airbus Defence", status: "Open", priority: "P1", sla: "1h 09m", owner: "timo", lastMsg: "Need device posture export filtered by region." },
];

export const forecast = {
  quarter: "Q3 2026",
  commit: 4200000,
  bestCase: 6800000,
  pipeline: 11500000,
  closed: 1840000,
  target: 7500000,
  delta: 0.12,
  waterfall: [
    { name: "Closed Won", value: 1840000, type: "won" },
    { name: "Commit", value: 2360000, type: "commit" },
    { name: "Best Case", value: 2600000, type: "best" },
    { name: "Pipeline", value: 4700000, type: "pipe" },
  ],
};

export const kpis = [
  { label: "Pipeline value", value: "€11.5M", delta: 8.2, trend: [4, 6, 5, 8, 9, 11, 10, 12] },
  { label: "Win rate (90d)", value: "38%", delta: 4.1, trend: [30, 32, 31, 34, 36, 35, 37, 38] },
  { label: "Avg deal cycle", value: "62d", delta: -6.5, trend: [80, 78, 74, 72, 68, 66, 64, 62] },
  { label: "Quota attainment", value: "84%", delta: 12.0, trend: [40, 48, 56, 62, 70, 75, 80, 84] },
];

export const automations = [
  { id: "a1", name: "When deal stalls 7d → notify owner + suggest NBA", trigger: "Stage idle 7d", action: "Slack + Create task", on: true, runs: 142 },
  { id: "a2", name: "When discount > 15% → require Sales Manager approval", trigger: "Discount > 15%", action: "Approval chain", on: true, runs: 38 },
  { id: "a3", name: "When MDM case P1 opened → page TAM on-call", trigger: "Case P1", action: "PagerDuty + Slack", on: true, runs: 12 },
  { id: "a4", name: "When deal closes won → kickoff TAM playbook", trigger: "Closed Won", action: "Create project + assign TAM", on: true, runs: 28 },
  { id: "a5", name: "When account health < 60 → schedule health check", trigger: "Health < 60", action: "Create task + email", on: false, runs: 4 },
];

export const aiMessages = [
  { role: "user", text: "Which deals in Q3 are at risk and why?" },
  { role: "ai", text: "Three deals are showing elevated risk for Q3:", refs: ["d4", "d2", "d6"] },
];

export const offerSample = {
  id: "o-2026-0184",
  account: "Siemens Energy",
  title: "Field engineers expansion — 1,200 secure devices",
  prepared: "Sofia Lindqvist",
  validUntil: "2026-07-31",
  total: 1248000,
  currency: "EUR",
  discount: 8,
  lines: [
    { sku: "HMD-PRO-512", name: "HMD Secure Pro 512GB", qty: 1200, unit: 720, total: 864000 },
    { sku: "HMD-MDM-ENT", name: "Enterprise MDM seat (12mo)", qty: 1200, unit: 180, total: 216000 },
    { sku: "HMD-VPN-EU", name: "EU Sovereign VPN add-on", qty: 1200, unit: 90, total: 108000 },
    { sku: "HMD-SUP-24", name: "24/7 TAM support", qty: 1, unit: 60000, total: 60000 },
  ],
  approvals: [
    { step: "Sales Rep", who: "Sofia Lindqvist", status: "done" },
    { step: "Sales Manager", who: "Mira Schneider", status: "current" },
    { step: "Finance", who: "Fiona O'Connell", status: "pending" },
  ],
};

export function fmt(n: number, ccy = "EUR") {
  return new Intl.NumberFormat("en-EU", { style: "currency", currency: ccy, maximumFractionDigits: 0 }).format(n);
}
