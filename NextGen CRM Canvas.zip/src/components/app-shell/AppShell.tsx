import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, KanbanSquare, Building2, MessageSquare,
  TrendingUp, FileText, Zap, Sparkles, Bell, Search, ChevronsLeft,
  Settings, Wallet, ShieldCheck,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { AiBubble } from "./AiBubble";

const nav = [
  { to: "/rep", label: "Dashboard", icon: LayoutDashboard },
  { to: "/pipeline", label: "Pipeline", icon: KanbanSquare },
  { to: "/contacts", label: "Contacts", icon: Users },
  { to: "/accounts/siemens", label: "Accounts", icon: Building2 },
  { to: "/cases", label: "Cases", icon: MessageSquare },
  { to: "/forecast", label: "Forecast", icon: TrendingUp },
  { to: "/offers/o-2026-0184", label: "Offers", icon: FileText },
  { to: "/automations", label: "Automations", icon: Zap },
  { to: "/manager", label: "Manager", icon: ShieldCheck },
  { to: "/finance", label: "Finance", icon: Wallet },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="flex min-h-screen w-full bg-background text-foreground">
      <aside
        className={`sticky top-0 h-screen shrink-0 border-r border-sidebar-border bg-sidebar transition-all duration-200 ${
          collapsed ? "w-[68px]" : "w-[232px]"
        }`}
      >
        <div className="flex h-14 items-center gap-2 px-4">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg ai-gradient shadow-elegant">
            <ShieldCheck className="h-4 w-4 text-white" />
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <div className="font-display text-sm font-semibold leading-tight">HMD Secure</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">CRM · EU Sovereign</div>
            </div>
          )}
        </div>
        <nav className="flex flex-col gap-0.5 px-2 py-2">
          {nav.map(({ to, label, icon: Icon }) => {
            const active = path === to || (to !== "/rep" && path.startsWith(to.split("/").slice(0, 2).join("/")));
            return (
              <Link
                key={to}
                to={to as any}
                className={`group flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  active
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <Icon className={`h-4 w-4 shrink-0 ${active ? "text-primary-glow" : ""}`} />
                {!collapsed && <span className="truncate">{label}</span>}
                {!collapsed && active && (
                  <span className="ml-auto h-1.5 w-1.5 rounded-full bg-primary-glow ai-pulse" />
                )}
              </Link>
            );
          })}
        </nav>
        <div className="absolute bottom-3 left-0 right-0 px-2">
          <Link to={"/assistant" as any} className="mb-2 flex items-center gap-3 rounded-lg border border-border bg-card px-3 py-2 text-sm hover:bg-secondary">
            <Sparkles className="h-4 w-4 text-primary-glow" />
            {!collapsed && <span className="ai-gradient-text font-medium">AI Assistant</span>}
          </Link>
          <button
            onClick={() => setCollapsed((c) => !c)}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs text-muted-foreground hover:bg-secondary"
          >
            <ChevronsLeft className={`h-4 w-4 transition-transform ${collapsed ? "rotate-180" : ""}`} />
            {!collapsed && <span>Collapse</span>}
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border bg-background/80 px-6 backdrop-blur-xl">
          <div className="relative flex max-w-xl flex-1 items-center">
            <Search className="absolute left-3 h-4 w-4 text-muted-foreground" />
            <input
              placeholder="Search accounts, deals, cases, contacts…  ⌘K"
              className="h-9 w-full rounded-lg border border-border bg-secondary/40 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <button className="relative grid h-9 w-9 place-items-center rounded-lg border border-border hover:bg-secondary">
            <Bell className="h-4 w-4" />
            <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-destructive" />
          </button>
          <button className="grid h-9 w-9 place-items-center rounded-lg border border-border hover:bg-secondary">
            <Settings className="h-4 w-4" />
          </button>
          <Link to={"/login" as any} className="flex items-center gap-2 rounded-lg border border-border px-2 py-1.5 hover:bg-secondary">
            <div className="grid h-7 w-7 place-items-center rounded-md bg-gradient-to-br from-primary to-primary-glow text-[11px] font-semibold text-primary-foreground">
              SL
            </div>
            <div className="hidden sm:block text-left">
              <div className="text-xs font-medium leading-tight">Sofia L.</div>
              <div className="text-[10px] text-muted-foreground">Sales Rep</div>
            </div>
          </Link>
        </header>
        <main className="min-w-0 flex-1">{children}</main>
      </div>

      <AiBubble />
    </div>
  );
}
