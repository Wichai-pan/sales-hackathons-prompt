// Reference shape for your app/layout.tsx. Adjust auth/session lookup to your project.
import "@/styles/globals.css";
import { AppShell } from "@/components/AppShell";
import type { Role, User } from "@/lib/types";

// import { getServerSession } from "next-auth"; // or whatever you use
// import { prisma } from "@/lib/prisma";

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // Replace with your real session + db lookup:
  const user: User = {
    id: "demo",
    name: "Sofia Lindqvist",
    email: "sofia@hmd.example",
    role: "REP",
    avatarHue: 280,
  };
  const role: Role = user.role;
  const unreadCount = 0; // await prisma.notification.count({ where: { userId: user.id, readAt: null } })

  return (
    <html lang="en" className="dark">
      <body>
        <AppShell role={role} user={user} unreadCount={unreadCount}>
          {children}
        </AppShell>
      </body>
    </html>
  );
}
