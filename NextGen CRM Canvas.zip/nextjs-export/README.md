# HMD Secure CRM — Next.js drop-in UI

This folder is a **code-shape refactor** of the Lovable preview into the exact stack you asked for:

- Next.js 15 (App Router, RSC) + React 19 + TypeScript
- Tailwind CSS **v3.4** (config-based, NOT v4)
- Icons: `lucide-react`
- Class utils: `clsx` + `tailwind-merge` + `class-variance-authority`
- **No** Vite / TanStack / Radix / recharts / framer-motion / mock data

## NPM packages required (beyond your existing app)

Already in your stack? Skip. Otherwise install:

```bash
npm i lucide-react class-variance-authority clsx tailwind-merge
# Tailwind v3 toolchain (only if not already installed):
npm i -D tailwindcss@^3.4 postcss autoprefixer
```

**That's it — no other runtime deps.** Charts are plain inline SVG, the
sidebar/sheet/dropdown are dependency-free. If you later want focus-trapped
dialogs etc. you can add Radix; nothing in this folder requires it.

## How to drop in

1. Copy `styles/globals.css` over your existing `app/globals.css`
   (or merge the token & layer blocks).
2. Copy `tailwind.config.ts` to your project root (merge `content` paths
   with whatever you already scan).
3. Copy `lib/`, `components/ui/`, `components/primitives.tsx`,
   `components/AppShell.tsx`, `components/AiBubble.tsx`,
   `components/screens/*` into your `components/` and `lib/` folders.
   Adjust `@/` alias if needed.
4. In your `app/layout.tsx`, wrap children with `<AppShell role nav user>`.
   See `app-layout.example.tsx` for the exact shape.
5. In each `app/<route>/page.tsx`, fetch your Prisma data on the server,
   then render the matching screen component:

   ```tsx
   // app/rep/page.tsx
   import { RepDashboardScreen } from "@/components/screens/RepDashboardScreen";
   import { getRepDashboardData } from "@/lib/queries/rep"; // YOU implement

   export default async function Page() {
     const data = await getRepDashboardData();
     return <RepDashboardScreen data={data} />;
   }
   ```

   Each screen exports a `*Data` TypeScript type — wire your Prisma rows
   to that shape and you're done.

## What's in here

| File                                                    | Purpose                                                                      |
| ------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `styles/globals.css`                                    | Tailwind v3 directives + design tokens + `.glass-card` / `.ai-gradient` etc. |
| `tailwind.config.ts`                                    | Token wrapper so `bg-primary/40` etc. work via oklch + `<alpha-value>`.      |
| `lib/utils.ts`                                          | `cn()` helper (clsx + tailwind-merge).                                       |
| `lib/types.ts`                                          | Every entity (Account, Deal, Offer, Case, …) typed for your Prisma layer.   |
| `lib/format.ts`                                         | `fmt()` currency / `fmtPct()` / `slaLabel()` etc.                            |
| `components/ui/*`                                       | Canonical shadcn-shape primitives (Button, Badge, Card, Input, Table).       |
| `components/primitives.tsx`                             | KpiTile, SparkLine, HealthRing, AIChip, Avatar, SectionHeader, GlassCard.    |
| `components/AppShell.tsx` / `AiBubble.tsx`              | Role-aware sidebar + top header + floating AI bubble (no framer-motion).     |
| `components/screens/*.tsx`                              | One screen = one prop-driven component, no fetching inside.                  |
| `app-layout.example.tsx`                                | Reference `app/layout.tsx` for your project.                                 |

## Rules every screen follows

1. Receives all data via a typed `data` prop. No `seed.ts`, no `fetch()`.
2. Every `<form>` accepts an `action` prop (server action). Defaults to a
   no-op so the screen renders in Storybook. Every input/select/textarea
   has a semantic `name="..."`.
3. No `useState` write-back to a fake store. Only ephemeral UI state
   (e.g. "which tab is open") uses local state, and those components are
   `"use client"`.
4. Visual design is byte-identical to the Lovable preview — same spacing,
   colors, fonts, gradients, glass cards, charts.
