import type { Config } from "tailwindcss";

/** Wrap an oklch CSS var so opacity utilities (bg-primary/40) still work. */
const c = (v: string) => `oklch(var(${v}) / <alpha-value>)`;

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    container: { center: true, padding: "1rem", screens: { "2xl": "1400px" } },
    extend: {
      fontFamily: {
        sans: ["Manrope", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["Sora", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
      borderRadius: {
        sm: "calc(var(--radius) - 4px)",
        md: "calc(var(--radius) - 2px)",
        lg: "var(--radius)",
        xl: "calc(var(--radius) + 4px)",
        "2xl": "calc(var(--radius) + 8px)",
        "3xl": "calc(var(--radius) + 12px)",
      },
      colors: {
        background: c("--background"),
        foreground: c("--foreground"),
        card: { DEFAULT: c("--card"), foreground: c("--card-foreground") },
        elevated: c("--elevated"),
        popover: { DEFAULT: c("--popover"), foreground: c("--popover-foreground") },
        primary: {
          DEFAULT: c("--primary"),
          foreground: c("--primary-foreground"),
          glow: c("--primary-glow"),
        },
        secondary: { DEFAULT: c("--secondary"), foreground: c("--secondary-foreground") },
        muted: { DEFAULT: c("--muted"), foreground: c("--muted-foreground") },
        accent: { DEFAULT: c("--accent"), foreground: c("--accent-foreground") },
        destructive: { DEFAULT: c("--destructive"), foreground: c("--destructive-foreground") },
        success: c("--success"),
        warning: c("--warning"),
        info: c("--info"),
        border: c("--border"),
        input: c("--input"),
        ring: c("--ring"),
        sidebar: {
          DEFAULT: c("--sidebar"),
          foreground: c("--sidebar-foreground"),
          border: c("--sidebar-border"),
        },
        chart: {
          1: c("--chart-1"),
          2: c("--chart-2"),
          3: c("--chart-3"),
          4: c("--chart-4"),
          5: c("--chart-5"),
        },
      },
    },
  },
  plugins: [],
};

export default config;
